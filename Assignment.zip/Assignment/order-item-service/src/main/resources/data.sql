insert into order_item (product_code ,product_name, quantity) values (10001, 'Amul', 1);
insert into order_item (product_code ,product_name, quantity) values (10002, 'washing powder', 3);
insert into order_item (product_code ,product_name, quantity)  values (10003, 'Frooti', 2);
insert into order_item (product_code ,product_name, quantity)  values (10004, 'Maaza', 1);
insert into order_item (product_code ,product_name, quantity)  values (10005, 'Paper Boat',2);